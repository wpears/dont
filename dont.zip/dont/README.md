Blocks the Page Visibility API with some prototype hacking.

Available as a Chrome Extension [here](https://chrome.google.com/webstore/detail/dont-make-me-watch/ahjofnjojbnikkffhagdddimbcmcphhh).
